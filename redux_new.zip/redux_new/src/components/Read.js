// Read.js
import React, { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { showUser, deleteUser, SearchUser } from "../features/userDetailSlice";
// Modal class directly from bootstrap JS
import Modal from "bootstrap/js/dist/modal";
import { Link } from "react-router-dom";

const Read = () => {
  const dispatch = useDispatch();

  // provide safe defaults to avoid runtime errors
  const { users = [], loading = false, searchData = "" } =
    useSelector((state) => state.userDetail || {});

  const [selectedUser, setSelectedUser] = useState(null);
  const modalRef = useRef(null);
  const bsModalRef = useRef(null);

  useEffect(() => {
    // fetch users when component mounts
    dispatch(showUser());
  }, [dispatch]);

  // cleanup Modal instance on unmount
  useEffect(() => {
    return () => {
      if (bsModalRef.current) {
        try {
          bsModalRef.current.dispose();
        } catch (e) {
          /* ignore dispose errors */
        }
        bsModalRef.current = null;
      }
    };
  }, []);

  const handleView = (item) => {
    setSelectedUser(item);

    // create bootstrap modal instance only once
    if (!bsModalRef.current && modalRef.current) {
      bsModalRef.current = new Modal(modalRef.current, { backdrop: "static" });
    }

    if (bsModalRef.current) {
      bsModalRef.current.show();
    }
  };

  const handleCloseModal = () => {
    if (bsModalRef.current) {
      bsModalRef.current.hide();
    }
    setSelectedUser(null);
  };

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete this user?")) return;

    // dispatch delete thunk (assuming deleteUser is an async thunk)
    dispatch(deleteUser(id))
      .unwrap()
      .then(() => { })
      .catch((err) => {
        console.error("Delete failed:", err);
      });
  };

  if (loading) return <h1>Loading...</h1>;

  // safe normalized query
  const q = (searchData || "").toString().toLowerCase().trim();

  return (
    <div>
      <h1>All Data</h1>

      <div className="container">
        <div className="row">
          {users &&
            users
              .filter((item) => {
                if (!q) return true;
                   return (item.name || "").toLowerCase().includes(q);
              })
              .map((item) => (
                <div key={item.id ?? item.email} className="col-3 mb-3">
                  <div className="card p-2">
                    <div className="card-body p-2 text-start">
                      <h5 className="card-title fs-6">Name: {item.name}</h5>

                      <h6 className="card-subtitle mb-2 text-body-secondary fs-6">
                        <p className="mb-1">Email: {item.email}</p>
                      </h6>

                      <p className="card-text mb-0 fs-6">
                        Gender: {item.gender || "N/A"}
                      </p>

                      <div className="d-flex gap-2 mt-2">
                        <button
                          className="btn btn-info text-white"
                          type="button"
                          onClick={() => handleView(item)}
                        >View
                        </button>

                        <Link className="btn btn-primary" to={`/edit/${item.id}`}>
                          Edit
                        </Link>

                        <button
                          className="btn btn-danger"
                          onClick={() => handleDelete(item.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
        </div>
      </div>

      {/* Modal (ref used by bootstrap Modal) */}
      <div
        className="modal fade"
        tabIndex="-1"
        ref={modalRef}
        aria-hidden="true"
        role="dialog"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title">User Details</h5>
              <button
                type="button"
                className="btn-close"
                aria-label="Close"
                onClick={handleCloseModal}
              />
            </div>

            <div className="modal-body">
              {selectedUser ? (
                <>
                  <p>
                    <strong>Name:</strong> {selectedUser.name}
                  </p>
                  <p>
                    <strong>Email:</strong> {selectedUser.email}
                  </p>
                  <p>
                    <strong>Gender:</strong> {selectedUser.gender || "N/A"}
                  </p>
                  <p>
                    <strong>Age:</strong> {selectedUser.age ?? "N/A"}
                  </p>
                </>
              ) : (
                <p>No data found</p>
              )}
            </div>

            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={handleCloseModal}>
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Read;
