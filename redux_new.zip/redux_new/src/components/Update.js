// Update.js
import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useParams, useNavigate } from "react-router-dom";
import { showUser, updateUser } from "../features/userDetailSlice";

const Update = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  // align selector with Read.js (assumes slice shape: { users: [], loading: false })
  const { users = [], loading = false } = useSelector((state) => state.userDetail || {});

  const [updateData, setUpdateData] = useState(null);

  // ensure users are loaded (call showUser if empty)
  useEffect(() => {
    if (!users || users.length === 0) {
      dispatch(showUser());
    }
  }, [dispatch, users]);

  // when users arrive or id changes, find the user and set form state
  useEffect(() => {
    if (id && users && users.length > 0) {
      const singleUser = users.find((item) => String(item.id) === String(id));
      if (singleUser) {
        setUpdateData(singleUser);
      } else {
        // if id not found, optionally navigate back or show message
        console.warn("User not found with id:", id);
        // navigate("/"); // uncomment if you want to redirect
      }
    }
  }, [id, users]);

  const newData = (e) => {
    const { name, value, type } = e.target;
    
    setUpdateData((prev) => ({ ...(prev || {}), [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Submitting update:", updateData);
    navigate("/read");

    // if you have an updateUser thunk, dispatch it here, e.g.:
    dispatch(updateUser(updateData))
      .unwrap()
      .then(() => navigate("/read")) // redirect after success
      .catch(err => console.error(err));

    // For now just log (or implement update thunk)
  };

  if (loading && !updateData) return <h1>Loading...</h1>;

 
  if (!updateData) {
    return (
      <div className="container">
        <h2 className="my-2">Edit the data</h2>
        <p>No user found to edit. Make sure users are loaded and the id is correct.</p>
        <pre>{JSON.stringify({ id, usersLength: users.length }, null, 2)}</pre>
      </div>
    );
  }

  return (
    <div>
      <h2 className="my-2">Edit the data</h2>

      
      <form className="w-50 mx-auto" onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            type="text"
            name="name"
            className="form-control"
            onChange={newData}
            required
            value={updateData?.name ?? ""}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Email</label>
          <input
            type="email"
            name="email"
            className="form-control"
            onChange={newData}
            required
            value={updateData?.email ?? ""}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Age</label>
          <input
            type="text"
            name="age"
            className="form-control"
            onChange={newData}
            required
            value={updateData?.age ?? ""}
          />
        </div>

        <div className="mb-3">
          <input
            className="form-check-input"
            name="gender"
            value="Male"
            type="radio"
            onChange={newData}
            checked={updateData?.gender === "Male"}
            required
            id="genderMale"
          />
          <label className="form-check-label ms-2" htmlFor="genderMale">Male</label>
        </div>

        <div className="mb-3">
          <input
            className="form-check-input"
            name="gender"
            value="Female"
            type="radio"
            onChange={newData}
            checked={updateData?.gender === "Female"}
            id="genderFemale"
          />
          <label className="form-check-label ms-2" htmlFor="genderFemale">Female</label>
        </div>

        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </div>
  );
};

export default Update;
