import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { SearchUser } from "../features/userDetailSlice";
const Navbar = () => {
  const allusers = useSelector((state)=>state.userDetail.users);
  const dispatch = useDispatch();
  const [ searchData, setSearchData] = useState("");
 
  console.log(searchData);
  useEffect(()=>{
        dispatch(SearchUser(searchData));
  },[searchData])
  
  return (
    <div style={{backgroundColor:"#fff"}}>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">
          RTL
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active" aria-current="page" to="/">
                  Create Post
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/read">
                  All Post ({allusers.length})
                </Link>
              </li>
              
            
            </ul>
            <form className="d-flex" role="search">
              <input
                className="form-control me-2"
                type="search"
                placeholder="Search"
                aria-label="Search"
                onChange={(e)=>setSearchData(e.target.value)}

              />
              
            </form>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
