// userDetailSlice.js
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

const API_BASE = "https://691305ea52a60f10c823b651.mockapi.io/CRUD";

/**
 * createUser - POST a new user
 */
export const createUser = createAsyncThunk(
  "userDetail/createUser",
  async (data, { rejectWithValue }) => {
    try {
      const response = await fetch(API_BASE, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        let errText;
        try {
          const errJson = await response.json();
          errText = errJson?.message || JSON.stringify(errJson);
        } catch {
          errText = `HTTP ${response.status}`;
        }
        return rejectWithValue(errText);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      return rejectWithValue(error.message || "Something went wrong");
    }
  }
);

export const showUser = createAsyncThunk(
  "userDetail/showUser",
  async (_, { rejectWithValue }) => {
    try {
      const response = await fetch(API_BASE);

      if (!response.ok) {
        return rejectWithValue(`HTTP ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      return rejectWithValue(error.message || "Failed to fetch users");
    }
  }
);

// DELETE thunk
export const deleteUser = createAsyncThunk(
  "userDetail/deleteUser",
  async (id, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_BASE}/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        return rejectWithValue(`HTTP ${response.status}`);
      }

      const data = await response.json();
      if (data && (data.id || data.ID || data.Id)) return data;
      return { id };
    } catch (error) {
      return rejectWithValue(error.message || "Failed to delete user");
    }
  }
);

// update user
export const updateUser = createAsyncThunk(
  "userDetail/updateUser",
  async (data, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_BASE}/${data.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        let errText = "Failed to update user";
        try {
          const errJson = await response.json();
          errText = errJson?.message || JSON.stringify(errJson) || errText;
        } catch {}
        return rejectWithValue(errText);
      }

      const result = await response.json();
      return result;
    } catch (error) {
      return rejectWithValue(error.message || "Failed to update user");
    }
  }
);

const initialState = {
  users: [],
  loading: false,
  error: null,
  // use lowercase searchData so it's easy to consume (string)
  searchData: "",
};

const userDetail = createSlice({
  name: "userDetail",
  initialState,
  reducers: {
    setLoading(state, action) {
      state.loading = action.payload;
    },
    addUser(state, action) {
      state.users.push(action.payload);
    },
    setError(state, action) {
      state.error = action.payload;
    },
    // keep the reducer name you were using elsewhere, but store in `searchData`
    SearchUser(state, action) {
      state.searchData = action.payload;
    },
  },

  extraReducers: (builder) => {
    // showUser
    builder
      .addCase(showUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(showUser.fulfilled, (state, action) => {
        state.loading = false;
        state.users = action.payload || [];
      })
      .addCase(showUser.rejected, (state, action) => {
        state.loading = false;
        state.error =
          action.payload || action.error?.message || "Failed to load users";
      });

    // createUser
    builder
      .addCase(createUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createUser.fulfilled, (state, action) => {
        state.loading = false;
        state.users.push(action.payload);
      })
      .addCase(createUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error?.message;
      });

    // updateUser
    builder
      .addCase(updateUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateUser.fulfilled, (state, action) => {
        state.loading = false;
        const updated = action.payload;
        if (updated && updated.id !== undefined) {
          state.users = state.users.map((item) =>
            String(item.id) === String(updated.id) ? updated : item
          );
        }
      })
      .addCase(updateUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error?.message;
      });

    // deleteUser
    builder
      .addCase(deleteUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteUser.fulfilled, (state, action) => {
        state.loading = false;

        const payloadId =
          action.payload?.id ??
          action.payload?.ID ??
          action.payload?.Id ??
          action.meta?.arg;

        if (payloadId !== undefined && payloadId !== null) {
          state.users = state.users.filter(
            (u) => String(u.id) !== String(payloadId)
          );
        }
      })
      .addCase(deleteUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || action.error?.message;
      });
  },
});

export const { setLoading, addUser, SearchUser, setError } = userDetail.actions;
export default userDetail.reducer;
